# Dot-art by Yoshi-kun

*Ported by Cindy Nemi and Aemiii91*

Source: http://yspixel.jpn.org/icon/game/

Missing icons have been substituted with resized versions from the [Pixel Art Icon Pack by faustbear](https://www.reddit.com/r/miniSNESmods/comments/995ylx/additional_pixel_art_icon_pack_22/).
